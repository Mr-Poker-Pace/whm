
const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Data storage (in production, use a database)
let members = [];
let packages = [];
let invoices = [];
let services = [];
let transactions = [];
let admins = [
    { id: 1, username: 'admin', password: 'admin123', email: 'admin@webmanagerpro.com', name: 'Administrator' }
];
let staff = [
    { id: 1, username: 'john.dev', password: 'staff123', email: 'john@webmanagerpro.com', name: 'John Developer', role: 'Developer', skills: 'React, Node.js, PHP' },
    { id: 2, username: 'sarah.support', password: 'staff123', email: 'sarah@webmanagerpro.com', name: 'Sarah Support', role: 'Support', skills: 'Customer Service' }
];
let projects = [];
let prospects = [];
let paymentMethods = [
    { id: 1, name: 'Transfer Bank', type: 'bank_transfer', enabled: true },
    { id: 2, name: 'Virtual Account BCA', type: 'va_bca', enabled: true },
    { id: 3, name: 'Virtual Account Mandiri', type: 'va_mandiri', enabled: true },
    { id: 4, name: 'OVO', type: 'ovo', enabled: true },
    { id: 5, name: 'DANA', type: 'dana', enabled: true },
    { id: 6, name: 'GoPay', type: 'gopay', enabled: true },
    { id: 7, name: 'Bitcoin', type: 'bitcoin', enabled: true },
    { id: 8, name: 'USDT', type: 'usdt', enabled: true }
];
let recurringPayments = [];
let chatSessions = [];
let notifications = [];
let analytics = [];
let ratings = [];
let subscriptions = [];
let affiliates = [];

// Initialize default data
function initializeData() {
  // Default service packages
  packages = [
    { id: 1, name: 'Basic Website', price: 500000, features: ['5 Pages', 'Responsive Design', 'Contact Form', '1 Year Hosting'] },
    { id: 2, name: 'Business Website', price: 1000000, features: ['10 Pages', 'Responsive Design', 'Contact Form', 'SEO Optimization', '1 Year Hosting', 'SSL Certificate'] },
    { id: 3, name: 'E-commerce Basic', price: 1500000, features: ['Product Catalog', 'Shopping Cart', 'Payment Gateway', 'Order Management', '1 Year Hosting'] },
    { id: 4, name: 'E-commerce Advanced', price: 2500000, features: ['Unlimited Products', 'Advanced Analytics', 'Multi-payment Gateway', 'Inventory Management', '2 Years Hosting'] },
    { id: 5, name: 'Corporate Website', price: 3000000, features: ['20+ Pages', 'CMS Integration', 'Multi-language', 'Advanced SEO', '2 Years Hosting'] },
    // Add more packages to reach 30
    { id: 6, name: 'Portfolio Website', price: 750000, features: ['Gallery', 'Portfolio Showcase', 'Contact Form', '1 Year Hosting'] },
    { id: 7, name: 'Blog Website', price: 800000, features: ['Blog System', 'Comment System', 'Social Sharing', '1 Year Hosting'] },
    { id: 8, name: 'Restaurant Website', price: 1200000, features: ['Menu Display', 'Online Reservation', 'Location Map', '1 Year Hosting'] },
    { id: 9, name: 'Educational Website', price: 1800000, features: ['Course Management', 'Student Portal', 'Quiz System', '1 Year Hosting'] },
    { id: 10, name: 'Real Estate Website', price: 2000000, features: ['Property Listings', 'Search Filters', 'Agent Profiles', '1 Year Hosting'] },
    { id: 11, name: 'Medical Website', price: 1600000, features: ['Appointment Booking', 'Doctor Profiles', 'Service Info', '1 Year Hosting'] },
    { id: 12, name: 'Fitness Website', price: 1400000, features: ['Class Schedules', 'Trainer Profiles', 'Membership Plans', '1 Year Hosting'] },
    { id: 13, name: 'Travel Website', price: 2200000, features: ['Tour Packages', 'Booking System', 'Gallery', '1 Year Hosting'] },
    { id: 14, name: 'Photography Website', price: 1100000, features: ['Photo Gallery', 'Client Login', 'Booking Form', '1 Year Hosting'] },
    { id: 15, name: 'Wedding Website', price: 900000, features: ['Event Timeline', 'Guest RSVP', 'Photo Gallery', '1 Year Hosting'] },
    { id: 16, name: 'News Website', price: 1700000, features: ['Article Management', 'Category System', 'User Comments', '1 Year Hosting'] },
    { id: 17, name: 'NGO Website', price: 1300000, features: ['Donation System', 'Event Management', 'Volunteer Portal', '1 Year Hosting'] },
    { id: 18, name: 'Music Website', price: 1000000, features: ['Audio Player', 'Event Calendar', 'Fan Club', '1 Year Hosting'] },
    { id: 19, name: 'Gaming Website', price: 1500000, features: ['Game Reviews', 'Tournament System', 'User Rankings', '1 Year Hosting'] },
    { id: 20, name: 'Fashion Website', price: 1800000, features: ['Product Showcase', 'Size Guide', 'Style Blog', '1 Year Hosting'] },
    { id: 21, name: 'Technology Blog', price: 1200000, features: ['Tech Articles', 'Product Reviews', 'Newsletter', '1 Year Hosting'] },
    { id: 22, name: 'Food Website', price: 1100000, features: ['Recipe Database', 'Nutrition Info', 'Cooking Videos', '1 Year Hosting'] },
    { id: 23, name: 'Beauty Website', price: 1400000, features: ['Service Booking', 'Product Catalog', 'Beauty Tips', '1 Year Hosting'] },
    { id: 24, name: 'Auto Website', price: 1600000, features: ['Vehicle Listings', 'Comparison Tool', 'Dealer Network', '1 Year Hosting'] },
    { id: 25, name: 'Pet Website', price: 1000000, features: ['Pet Profiles', 'Vet Directory', 'Pet Care Tips', '1 Year Hosting'] },
    { id: 26, name: 'Home Services', price: 1300000, features: ['Service Booking', 'Professional Profiles', 'Review System', '1 Year Hosting'] },
    { id: 27, name: 'Legal Website', price: 1900000, features: ['Case Studies', 'Consultation Booking', 'Legal Resources', '1 Year Hosting'] },
    { id: 28, name: 'Construction Website', price: 1700000, features: ['Project Portfolio', 'Service Areas', 'Quote Request', '1 Year Hosting'] },
    { id: 29, name: 'Event Planning', price: 1500000, features: ['Event Gallery', 'Service Packages', 'Booking Calendar', '1 Year Hosting'] },
    { id: 30, name: 'Custom Enterprise', price: 5000000, features: ['Custom Development', 'Advanced Integration', 'Priority Support', '3 Years Hosting'] }
  ];
}

initializeData();

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/member-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'member-dashboard.html'));
});

app.get('/staff-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'staff-dashboard.html'));
});

// API Routes
app.get('/api/members', (req, res) => {
  res.json(members);
});

app.post('/api/members', (req, res) => {
  const member = {
    id: Date.now(),
    ...req.body,
    balance: 0,
    createdAt: new Date(),
    status: 'active',
    autoRenewal: false
  };
  members.push(member);
  res.json(member);
});

app.get('/api/packages', (req, res) => {
  res.json(packages);
});

app.post('/api/invoices', (req, res) => {
  const invoice = {
    id: Date.now(),
    invoiceNumber: `INV-${Date.now()}`,
    ...req.body,
    createdAt: new Date(),
    status: 'pending'
  };
  invoices.push(invoice);
  res.json(invoice);
});

app.get('/api/invoices', (req, res) => {
  res.json(invoices);
});

app.get('/api/invoices/:id/pdf', (req, res) => {
  const invoiceId = parseInt(req.params.id);
  const invoice = invoices.find(inv => inv.id === invoiceId);
  
  if (!invoice) {
    return res.status(404).json({ error: 'Invoice not found' });
  }
  
  res.json({ message: 'PDF generation feature would be implemented here', invoice });
});

// Authentication routes
app.post('/api/auth/admin/login', (req, res) => {
  const { username, password } = req.body;
  const admin = admins.find(a => a.username === username && a.password === password);
  
  if (admin) {
    const token = `admin_${Date.now()}_${admin.id}`;
    res.json({ 
      success: true, 
      token: token,
      user: { id: admin.id, username: admin.username, name: admin.name, email: admin.email }
    });
  } else {
    res.json({ success: false, message: 'Username atau password salah' });
  }
});

app.post('/api/auth/member/login', (req, res) => {
  const { email, password } = req.body;
  const member = members.find(m => m.email === email && m.password === password);
  
  if (member) {
    const token = `member_${Date.now()}_${member.id}`;
    res.json({ 
      success: true, 
      token: token,
      user: { id: member.id, name: member.name, email: member.email }
    });
  } else {
    res.json({ success: false, message: 'Email atau password salah' });
  }
});

app.post('/api/auth/staff/login', (req, res) => {
  const { username, password } = req.body;
  const staffMember = staff.find(s => s.username === username && s.password === password);
  
  if (staffMember) {
    const token = `staff_${Date.now()}_${staffMember.id}`;
    res.json({ 
      success: true, 
      token: token,
      user: { id: staffMember.id, name: staffMember.name, email: staffMember.email, role: staffMember.role }
    });
  } else {
    res.json({ success: false, message: 'Username atau password salah' });
  }
});

// Prospects API
app.get('/api/prospects', (req, res) => {
  res.json(prospects);
});

app.post('/api/prospects', (req, res) => {
  const prospect = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date(),
    status: 'new'
  };
  prospects.push(prospect);
  res.json(prospect);
});

// Balance and Transaction API
app.get('/api/members/:id/balance', (req, res) => {
  const memberId = parseInt(req.params.id);
  const member = members.find(m => m.id === memberId);
  
  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }
  
  res.json({ balance: member.balance || 0 });
});

app.post('/api/members/:id/topup', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { amount, method } = req.body;
  const member = members.find(m => m.id === memberId);
  
  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }
  
  member.balance = (member.balance || 0) + amount;
  
  // Create transaction record
  const transaction = {
    id: Date.now(),
    memberId: memberId,
    type: 'topup',
    amount: amount,
    method: method,
    description: `Top up saldo via ${method}`,
    createdAt: new Date(),
    status: 'completed'
  };
  transactions.push(transaction);
  
  res.json({ 
    success: true, 
    newBalance: member.balance, 
    transaction: transaction 
  });
});

app.post('/api/members/:id/auto-renewal', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { enabled } = req.body;
  const member = members.find(m => m.id === memberId);
  
  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }
  
  member.autoRenewal = enabled;
  res.json({ success: true, autoRenewal: member.autoRenewal });
});

app.post('/api/auto-renewal/process', (req, res) => {
  const renewalResults = [];
  
  members.forEach(member => {
    if (member.autoRenewal && member.services) {
      member.services.forEach(service => {
        const expiryDate = new Date(service.expiryDate);
        const today = new Date();
        const daysUntilExpiry = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));
        
        // Auto renewal 7 days before expiry
        if (daysUntilExpiry <= 7 && daysUntilExpiry > 0) {
          const pkg = packages.find(p => p.id === service.packageId);
          if (pkg && member.balance >= pkg.price) {
            // Deduct from balance
            member.balance -= pkg.price;
            
            // Extend service
            service.expiryDate = new Date(expiryDate.getTime() + (365 * 24 * 60 * 60 * 1000));
            
            // Create transaction
            const transaction = {
              id: Date.now() + Math.random(),
              memberId: member.id,
              type: 'auto_renewal',
              amount: -pkg.price,
              description: `Auto renewal for ${pkg.name}`,
              createdAt: new Date(),
              status: 'completed'
            };
            transactions.push(transaction);
            
            renewalResults.push({
              memberId: member.id,
              memberName: member.name,
              service: pkg.name,
              amount: pkg.price,
              newExpiry: service.expiryDate,
              status: 'success'
            });
          } else {
            renewalResults.push({
              memberId: member.id,
              memberName: member.name,
              service: pkg.name,
              amount: pkg.price,
              status: 'insufficient_balance'
            });
          }
        }
      });
    }
  });
  
  res.json({ processedRenewals: renewalResults });
});

app.get('/api/transactions', (req, res) => {
  const { memberId } = req.query;
  let filteredTransactions = transactions;
  
  if (memberId) {
    filteredTransactions = transactions.filter(t => t.memberId === parseInt(memberId));
  }
  
  res.json(filteredTransactions);
});

// Payment Methods API
app.get('/api/payment-methods', (req, res) => {
  res.json(paymentMethods.filter(pm => pm.enabled));
});

app.post('/api/payment-methods', (req, res) => {
  const paymentMethod = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date()
  };
  paymentMethods.push(paymentMethod);
  res.json(paymentMethod);
});

// Recurring Payments API
app.get('/api/recurring-payments', (req, res) => {
  res.json(recurringPayments);
});

app.post('/api/recurring-payments', (req, res) => {
  const recurringPayment = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date(),
    status: 'active',
    nextPaymentDate: new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)) // Next month
  };
  recurringPayments.push(recurringPayment);
  res.json(recurringPayment);
});

app.post('/api/recurring-payments/process', (req, res) => {
  const today = new Date();
  const processedPayments = [];
  
  recurringPayments.forEach(rp => {
    if (rp.status === 'active' && new Date(rp.nextPaymentDate) <= today) {
      const member = members.find(m => m.id === rp.memberId);
      if (member && member.balance >= rp.amount) {
        // Process payment
        member.balance -= rp.amount;
        
        // Create transaction
        const transaction = {
          id: Date.now() + Math.random(),
          memberId: rp.memberId,
          type: 'recurring_payment',
          amount: -rp.amount,
          description: `Recurring payment for ${rp.serviceName}`,
          createdAt: new Date(),
          status: 'completed'
        };
        transactions.push(transaction);
        
        // Update next payment date
        rp.nextPaymentDate = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000));
        
        processedPayments.push({
          paymentId: rp.id,
          memberId: rp.memberId,
          amount: rp.amount,
          status: 'success'
        });
      } else {
        processedPayments.push({
          paymentId: rp.id,
          memberId: rp.memberId,
          amount: rp.amount,
          status: 'insufficient_balance'
        });
      }
    }
  });
  
  res.json({ processedPayments });
});

// Invoice Customization API
app.post('/api/invoices/:id/customize', (req, res) => {
  const invoiceId = parseInt(req.params.id);
  const { logoUrl, brandColor, companyInfo, taxInfo } = req.body;
  const invoice = invoices.find(inv => inv.id === invoiceId);
  
  if (!invoice) {
    return res.status(404).json({ error: 'Invoice not found' });
  }
  
  invoice.customization = {
    logoUrl,
    brandColor,
    companyInfo,
    taxInfo,
    updatedAt: new Date()
  };
  
  res.json(invoice);
});

// Communication & Support API
app.get('/api/chat-sessions', (req, res) => {
  const { memberId } = req.query;
  let filteredSessions = chatSessions;
  
  if (memberId) {
    filteredSessions = chatSessions.filter(cs => cs.memberId === parseInt(memberId));
  }
  
  res.json(filteredSessions);
});

app.post('/api/chat-sessions', (req, res) => {
  const chatSession = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date(),
    status: 'active',
    messages: []
  };
  chatSessions.push(chatSession);
  res.json(chatSession);
});

app.post('/api/chat-sessions/:id/messages', (req, res) => {
  const sessionId = parseInt(req.params.id);
  const session = chatSessions.find(cs => cs.id === sessionId);
  
  if (!session) {
    return res.status(404).json({ error: 'Chat session not found' });
  }
  
  const message = {
    id: Date.now(),
    ...req.body,
    timestamp: new Date()
  };
  
  session.messages.push(message);
  
  // Auto-reply with AI bot (simplified)
  if (req.body.sender === 'member') {
    setTimeout(() => {
      const botReply = {
        id: Date.now() + 1,
        sender: 'bot',
        message: generateBotReply(req.body.message),
        timestamp: new Date()
      };
      session.messages.push(botReply);
    }, 1000);
  }
  
  res.json(message);
});

// Notification System API
app.get('/api/notifications', (req, res) => {
  const { memberId } = req.query;
  let filteredNotifications = notifications;
  
  if (memberId) {
    filteredNotifications = notifications.filter(n => n.memberId === parseInt(memberId));
  }
  
  res.json(filteredNotifications);
});

app.post('/api/notifications/broadcast', (req, res) => {
  const { title, message, type, targetAudience } = req.body;
  const notification = {
    id: Date.now(),
    title,
    message,
    type, // email, whatsapp, sms
    targetAudience, // all, active_members, specific_ids
    createdAt: new Date(),
    status: 'sent'
  };
  
  notifications.push(notification);
  
  // Simulate sending to members
  let targetMembers = members;
  if (targetAudience !== 'all') {
    targetMembers = members.filter(m => m.status === 'active');
  }
  
  res.json({
    notification,
    sentTo: targetMembers.length,
    message: `Notification sent to ${targetMembers.length} members`
  });
});

// Rating & Review System API
app.get('/api/ratings', (req, res) => {
  const { developerId } = req.query;
  let filteredRatings = ratings;
  
  if (developerId) {
    filteredRatings = ratings.filter(r => r.developerId === parseInt(developerId));
  }
  
  res.json(filteredRatings);
});

app.post('/api/ratings', (req, res) => {
  const rating = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date()
  };
  ratings.push(rating);
  res.json(rating);
});

// Analytics API
app.get('/api/analytics/traffic', (req, res) => {
  // Simulate Google Analytics data
  const trafficData = {
    pageViews: Math.floor(Math.random() * 10000) + 1000,
    uniqueVisitors: Math.floor(Math.random() * 5000) + 500,
    bounceRate: (Math.random() * 30 + 20).toFixed(2) + '%',
    avgSessionDuration: (Math.random() * 5 + 2).toFixed(2) + ' minutes',
    topPages: [
      { page: '/', views: Math.floor(Math.random() * 1000) + 100 },
      { page: '/products', views: Math.floor(Math.random() * 800) + 80 },
      { page: '/about', views: Math.floor(Math.random() * 600) + 60 }
    ]
  };
  
  res.json(trafficData);
});

app.get('/api/analytics/performance', (req, res) => {
  // Simulate performance monitoring data
  const performanceData = {
    uptime: (99.5 + Math.random() * 0.5).toFixed(2) + '%',
    avgLoadTime: (Math.random() * 2 + 1).toFixed(2) + 's',
    serverResponse: (Math.random() * 200 + 100).toFixed(0) + 'ms',
    lastDowntime: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    recommendations: [
      'Optimize images for faster loading',
      'Enable browser caching',
      'Minimize CSS and JavaScript files'
    ]
  };
  
  res.json(performanceData);
});

// Subscription & Membership API
app.get('/api/subscriptions', (req, res) => {
  res.json(subscriptions);
});

app.post('/api/subscriptions', (req, res) => {
  const subscription = {
    id: Date.now(),
    ...req.body,
    createdAt: new Date(),
    status: 'active',
    nextBilling: new Date(Date.now() + (30 * 24 * 60 * 60 * 1000))
  };
  subscriptions.push(subscription);
  res.json(subscription);
});

// Affiliate Program API
app.get('/api/affiliates', (req, res) => {
  res.json(affiliates);
});

app.post('/api/affiliates', (req, res) => {
  const affiliate = {
    id: Date.now(),
    ...req.body,
    affiliateCode: 'AFF' + Date.now().toString().slice(-6),
    commissionRate: 10, // 10% commission
    totalEarnings: 0,
    referralCount: 0,
    createdAt: new Date()
  };
  affiliates.push(affiliate);
  res.json(affiliate);
});

// Initialize more default data
let websites = [];
let cpanelAccounts = [];
let supportTickets = [];
let chatMessages = [];

// cPanel API endpoints
app.get('/api/members/:id/cpanel', (req, res) => {
  const memberId = parseInt(req.params.id);
  const member = members.find(m => m.id === memberId);
  
  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }
  
  // Get member's cPanel accounts
  const memberCpanelAccounts = cpanelAccounts.filter(cp => cp.memberId === memberId);
  
  res.json(memberCpanelAccounts);
});

app.post('/api/members/:id/cpanel', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { domain, username, password, cpanelUrl } = req.body;
  
  const cpanelAccount = {
    id: Date.now(),
    memberId: memberId,
    domain: domain,
    username: username,
    password: password, // In production, encrypt this
    cpanelUrl: cpanelUrl,
    createdAt: new Date(),
    status: 'active'
  };
  
  cpanelAccounts.push(cpanelAccount);
  res.json(cpanelAccount);
});

// Website Management API
app.get('/api/members/:id/websites', (req, res) => {
  const memberId = parseInt(req.params.id);
  const memberWebsites = websites.filter(w => w.memberId === memberId);
  res.json(memberWebsites);
});

app.post('/api/members/:id/websites', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { domain, packageId, sslEnabled } = req.body;
  
  const website = {
    id: Date.now(),
    memberId: memberId,
    domain: domain,
    packageId: packageId,
    sslEnabled: sslEnabled || false,
    status: 'active',
    createdAt: new Date(),
    expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000))
  };
  
  websites.push(website);
  res.json(website);
});

// Support Ticket API
app.get('/api/support-tickets', (req, res) => {
  const { memberId } = req.query;
  let filteredTickets = supportTickets;
  
  if (memberId) {
    filteredTickets = supportTickets.filter(t => t.memberId === parseInt(memberId));
  }
  
  res.json(filteredTickets);
});

app.post('/api/support-tickets', (req, res) => {
  const { memberId, subject, priority, message } = req.body;
  
  const ticket = {
    id: Date.now(),
    ticketId: 'TIC' + Date.now().toString().slice(-6),
    memberId: memberId,
    subject: subject,
    priority: priority,
    message: message,
    status: 'open',
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  supportTickets.push(ticket);
  res.json(ticket);
});

app.put('/api/support-tickets/:id', (req, res) => {
  const ticketId = parseInt(req.params.id);
  const { status, response } = req.body;
  
  const ticket = supportTickets.find(t => t.id === ticketId);
  if (!ticket) {
    return res.status(404).json({ error: 'Ticket not found' });
  }
  
  ticket.status = status;
  ticket.response = response;
  ticket.updatedAt = new Date();
  
  res.json(ticket);
});

// Chat API
app.get('/api/chat/:memberId', (req, res) => {
  const memberId = parseInt(req.params.memberId);
  const memberChats = chatMessages.filter(c => c.memberId === memberId);
  res.json(memberChats);
});

app.post('/api/chat/:memberId', (req, res) => {
  const memberId = parseInt(req.params.memberId);
  const { message, sender } = req.body;
  
  const chatMessage = {
    id: Date.now(),
    memberId: memberId,
    message: message,
    sender: sender, // 'member' or 'support'
    timestamp: new Date()
  };
  
  chatMessages.push(chatMessage);
  
  // Auto-reply from AI bot if from member
  if (sender === 'member') {
    setTimeout(() => {
      const botReply = {
        id: Date.now() + 1,
        memberId: memberId,
        message: generateBotReply(message),
        sender: 'bot',
        timestamp: new Date()
      };
      chatMessages.push(botReply);
    }, 1000);
  }
  
  res.json(chatMessage);
});

// Invoice API for members
app.get('/api/members/:id/invoices', (req, res) => {
  const memberId = parseInt(req.params.id);
  const memberInvoices = invoices.filter(inv => inv.memberId === memberId);
  res.json(memberInvoices);
});

app.post('/api/members/:id/invoices/:invoiceId/pay', (req, res) => {
  const memberId = parseInt(req.params.id);
  const invoiceId = parseInt(req.params.invoiceId);
  const { paymentMethod } = req.body;
  
  const invoice = invoices.find(inv => inv.id === invoiceId && inv.memberId === memberId);
  const member = members.find(m => m.id === memberId);
  
  if (!invoice || !member) {
    return res.status(404).json({ error: 'Invoice or member not found' });
  }
  
  let paymentSuccess = false;
  
  if (paymentMethod === 'balance') {
    if (member.balance >= invoice.amount) {
      member.balance -= invoice.amount;
      paymentSuccess = true;
      
      // Create transaction
      const transaction = {
        id: Date.now(),
        memberId: memberId,
        type: 'invoice_payment',
        amount: -invoice.amount,
        description: `Payment for invoice ${invoice.invoiceNumber}`,
        createdAt: new Date(),
        status: 'completed'
      };
      transactions.push(transaction);
    }
  } else {
    // Other payment methods
    paymentSuccess = true;
  }
  
  if (paymentSuccess) {
    invoice.status = 'paid';
    invoice.paidAt = new Date();
    
    res.json({ success: true, invoice: invoice, newBalance: member.balance });
  } else {
    res.json({ success: false, message: 'Saldo tidak mencukupi' });
  }
});

// Package purchase API
app.post('/api/members/:id/purchase', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { packageId, domain, paymentMethod } = req.body;
  
  const member = members.find(m => m.id === memberId);
  const pkg = packages.find(p => p.id === packageId);
  
  if (!member || !pkg) {
    return res.status(404).json({ error: 'Member or package not found' });
  }
  
  let paymentSuccess = false;
  
  if (paymentMethod === 'balance') {
    if (member.balance >= pkg.price) {
      member.balance -= pkg.price;
      paymentSuccess = true;
      
      // Create transaction
      const transaction = {
        id: Date.now(),
        memberId: memberId,
        type: 'package_purchase',
        amount: -pkg.price,
        description: `Purchase ${pkg.name}`,
        createdAt: new Date(),
        status: 'completed'
      };
      transactions.push(transaction);
    }
  } else {
    paymentSuccess = true;
  }
  
  if (paymentSuccess) {
    // Create website entry
    const website = {
      id: Date.now(),
      memberId: memberId,
      domain: domain,
      packageId: packageId,
      packageName: pkg.name,
      status: 'active',
      sslEnabled: true,
      createdAt: new Date(),
      expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000))
    };
    websites.push(website);
    
    // Create service entry
    if (!member.services) member.services = [];
    member.services.push({
      id: Date.now(),
      packageId: packageId,
      packageName: pkg.name,
      domain: domain,
      startDate: new Date(),
      expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)),
      status: 'active'
    });
    
    // Create cPanel account
    const cpanelAccount = {
      id: Date.now(),
      memberId: memberId,
      domain: domain,
      username: domain.split('.')[0],
      password: 'temp' + Date.now(),
      cpanelUrl: `https://cpanel.${domain}:2083`,
      createdAt: new Date(),
      status: 'active'
    };
    cpanelAccounts.push(cpanelAccount);
    
    res.json({ 
      success: true, 
      website: website,
      cpanelAccount: cpanelAccount,
      newBalance: member.balance 
    });
  } else {
    res.json({ success: false, message: 'Saldo tidak mencukupi' });
  }
});

// SSL Management API
app.post('/api/websites/:id/ssl', (req, res) => {
  const websiteId = parseInt(req.params.id);
  const { enable } = req.body;
  
  const website = websites.find(w => w.id === websiteId);
  if (!website) {
    return res.status(404).json({ error: 'Website not found' });
  }
  
  website.sslEnabled = enable;
  website.updatedAt = new Date();
  
  res.json(website);
});

// Backup Management API
app.post('/api/websites/:id/backup', (req, res) => {
  const websiteId = parseInt(req.params.id);
  const website = websites.find(w => w.id === websiteId);
  
  if (!website) {
    return res.status(404).json({ error: 'Website not found' });
  }
  
  const backup = {
    id: Date.now(),
    websiteId: websiteId,
    filename: `backup_${website.domain}_${Date.now()}.tar.gz`,
    size: Math.floor(Math.random() * 500) + 50 + 'MB',
    createdAt: new Date(),
    status: 'completed'
  };
  
  res.json(backup);
});

// Email Account Management API
app.get('/api/websites/:id/emails', (req, res) => {
  const websiteId = parseInt(req.params.id);
  // Mock email accounts
  const emailAccounts = [
    {
      id: 1,
      websiteId: websiteId,
      email: 'admin@example.com',
      quota: '1GB',
      used: '120MB',
      status: 'active'
    }
  ];
  
  res.json(emailAccounts);
});

app.post('/api/websites/:id/emails', (req, res) => {
  const websiteId = parseInt(req.params.id);
  const { email, password, quota } = req.body;
  
  const emailAccount = {
    id: Date.now(),
    websiteId: websiteId,
    email: email,
    password: password,
    quota: quota || '1GB',
    used: '0MB',
    status: 'active',
    createdAt: new Date()
  };
  
  res.json(emailAccount);
});

// Helper function for AI bot replies
function generateBotReply(message) {
  const responses = {
    'halo': 'Halo! Selamat datang di WebManager Pro. Ada yang bisa saya bantu?',
    'harga': 'Kami memiliki berbagai paket mulai dari Rp 500.000 untuk Basic Website hingga Rp 5.000.000 untuk Custom Enterprise. Paket mana yang Anda minati?',
    'hosting': 'Layanan hosting kami include SSL certificate, daily backup, dan 99.9% uptime guarantee. Apakah Anda ingin tahu lebih detail?',
    'support': 'Tim support kami siap membantu 24/7. Anda bisa menghubungi kami melalui chat, email, atau WhatsApp.',
    'pembayaran': 'Kami menerima berbagai metode pembayaran: Transfer Bank, Virtual Account, E-Wallet (OVO, DANA, GoPay), dan Cryptocurrency.',
    'cpanel': 'Untuk mengakses cPanel, silakan klik link yang tersedia di dashboard Website Saya. Username dan password sudah disediakan.',
    'ssl': 'SSL certificate gratis tersedia untuk semua paket. Jika ada masalah dengan SSL, silakan buat ticket support.',
    'backup': 'Backup otomatis dilakukan setiap hari. Anda juga bisa membuat backup manual melalui cPanel.',
    'email': 'Email hosting tersedia untuk semua paket. Anda bisa membuat email account melalui cPanel atau hubungi support.',
    'domain': 'Domain tersedia dalam berbagai ekstensi. Silakan pilih paket yang sudah termasuk domain atau beli terpisah.',
    'default': 'Terima kasih atas pertanyaan Anda. Tim support kami akan segera merespons. Sementara itu, Anda bisa cek FAQ di website kami.'
  };
  
  const lowerMessage = message.toLowerCase();
  for (const [key, response] of Object.entries(responses)) {
    if (lowerMessage.includes(key)) {
      return response;
    }
  }
  
  return responses.default;
}

app.get('/api/members/:id/services', (req, res) => {
  const memberId = parseInt(req.params.id);
  const member = members.find(m => m.id === memberId);
  
  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }
  
  res.json(member.services || []);
});

app.post('/api/members/:id/services', (req, res) => {
  const memberId = parseInt(req.params.id);
  const { packageId, paymentMethod } = req.body;
  const member = members.find(m => m.id === memberId);
  const pkg = packages.find(p => p.id === packageId);
  
  if (!member || !pkg) {
    return res.status(404).json({ error: 'Member or package not found' });
  }
  
  let paymentSuccess = false;
  
  if (paymentMethod === 'balance') {
    if (member.balance >= pkg.price) {
      member.balance -= pkg.price;
      paymentSuccess = true;
      
      // Create deduction transaction
      const transaction = {
        id: Date.now(),
        memberId: memberId,
        type: 'purchase',
        amount: -pkg.price,
        description: `Purchase ${pkg.name}`,
        createdAt: new Date(),
        status: 'completed'
      };
      transactions.push(transaction);
    }
  } else {
    // Other payment methods would be processed here
    paymentSuccess = true;
  }
  
  if (paymentSuccess) {
    if (!member.services) {
      member.services = [];
    }
    
    const service = {
      id: Date.now(),
      packageId: packageId,
      packageName: pkg.name,
      startDate: new Date(),
      expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)), // 1 year
      status: 'active'
    };
    
    member.services.push(service);
    
    res.json({ success: true, service: service, newBalance: member.balance });
  } else {
    res.json({ success: false, message: 'Saldo tidak mencukupi' });
  }
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
