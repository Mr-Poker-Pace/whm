
// Dashboard functionality
let members = [];
let packages = [];
let invoices = [];
let prospects = [];
let supportTickets = [];
let staff = [];
let projects = [];

// Show/hide sections
function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.add('d-none');
    });
    
    // Show selected section
    document.getElementById(sectionName).classList.remove('d-none');
    
    // Update active nav link
    document.querySelectorAll('.sidebar .nav-link').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Load section data
    if (sectionName === 'members') {
        loadMembers();
    } else if (sectionName === 'packages') {
        loadPackages();
    } else if (sectionName === 'invoices') {
        loadInvoices();
    } else if (sectionName === 'dashboard') {
        loadDashboardStats();
    } else if (sectionName === 'prospects') {
        loadProspects();
    } else if (sectionName === 'reports') {
        loadReports();
    } else if (sectionName === 'support') {
        loadSupportTickets();
    } else if (sectionName === 'analytics') {
        loadAnalyticsData();
    } else if (sectionName === 'payments') {
        loadPaymentMethods();
    } else if (sectionName === 'communications') {
        loadCommunications();
    } else if (sectionName === 'subscriptions') {
        loadSubscriptions();
    } else if (sectionName === 'staff') {
        loadStaff();
    } else if (sectionName === 'projects') {
        loadProjects();
    } else if (sectionName === 'websites') {
        loadWebsites();
    }
}

// Load dashboard statistics
function loadDashboardStats() {
    fetch('/api/members')
        .then(response => response.json())
        .then(data => {
            document.getElementById('totalMembers').textContent = data.length;
        })
        .catch(error => console.error('Error loading members:', error));
    
    fetch('/api/invoices')
        .then(response => response.json())
        .then(data => {
            const pendingCount = data.filter(inv => inv.status === 'pending').length;
            document.getElementById('pendingInvoices').textContent = pendingCount;
        })
        .catch(error => console.error('Error loading invoices:', error));
    
    // Mock data for active websites
    document.getElementById('activeWebsites').textContent = '25';
}

// Load members
function loadMembers() {
    fetch('/api/members')
        .then(response => response.json())
        .then(data => {
            members = data;
            displayMembers(data);
        })
        .catch(error => console.error('Error loading members:', error));
}

function displayMembers(membersData) {
    const tbody = document.getElementById('membersTable');
    tbody.innerHTML = '';
    
    membersData.forEach(member => {
        const row = `
            <tr>
                <td>${member.id}</td>
                <td>${member.name || 'N/A'}</td>
                <td>${member.email || 'N/A'}</td>
                <td>${member.phone || 'N/A'}</td>
                <td>Rp ${(member.balance || 0).toLocaleString('id-ID')}</td>
                <td>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" ${member.autoRenewal ? 'checked' : ''} 
                               onchange="toggleAutoRenewal(${member.id}, this.checked)">
                    </div>
                </td>
                <td><span class="badge bg-${member.status === 'active' ? 'success' : 'warning'}">${member.status || 'active'}</span></td>
                <td>${member.createdAt ? new Date(member.createdAt).toLocaleDateString('id-ID') : 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editMember(${member.id})">Edit</button>
                    <button class="btn btn-sm btn-info" onclick="topupMember(${member.id})">Top Up</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load packages
function loadPackages() {
    fetch('/api/packages')
        .then(response => response.json())
        .then(data => {
            packages = data;
            displayPackages(data);
        })
        .catch(error => console.error('Error loading packages:', error));
}

function displayPackages(packagesData) {
    const container = document.getElementById('packagesGrid');
    container.innerHTML = '';
    
    packagesData.forEach(pkg => {
        const card = `
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${pkg.name}</h5>
                        <p class="card-text">Rp ${pkg.price.toLocaleString('id-ID')}</p>
                        <ul class="list-unstyled">
                            ${pkg.features.map(feature => `<li><i class="fas fa-check text-success me-2"></i>${feature}</li>`).join('')}
                        </ul>
                        <button class="btn btn-primary btn-sm" onclick="editPackage(${pkg.id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deletePackage(${pkg.id})">Delete</button>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

// Load invoices
function loadInvoices() {
    fetch('/api/invoices')
        .then(response => response.json())
        .then(data => {
            invoices = data;
            displayInvoices(data);
        })
        .catch(error => console.error('Error loading invoices:', error));
}

function displayInvoices(invoicesData) {
    const tbody = document.getElementById('invoicesTable');
    tbody.innerHTML = '';
    
    invoicesData.forEach(invoice => {
        const row = `
            <tr>
                <td>${invoice.invoiceNumber || invoice.id}</td>
                <td>${invoice.clientName || 'N/A'}</td>
                <td>Rp ${(invoice.amount || 0).toLocaleString('id-ID')}</td>
                <td><span class="badge bg-${invoice.status === 'paid' ? 'success' : 'warning'}">${invoice.status || 'pending'}</span></td>
                <td>${invoice.createdAt ? new Date(invoice.createdAt).toLocaleDateString('id-ID') : 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="viewInvoice(${invoice.id})">View</button>
                    <button class="btn btn-sm btn-success" onclick="markPaid(${invoice.id})">Mark Paid</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load prospects
function loadProspects() {
    fetch('/api/prospects')
        .then(response => response.json())
        .then(data => {
            prospects = data;
            displayProspects(data);
        })
        .catch(error => {
            console.error('Error loading prospects:', error);
            // Display default data if API fails
            displayProspects([
                {
                    id: 1,
                    name: 'Sarah Johnson',
                    email: 'sarah@example.com',
                    phone: '081234567890',
                    interestedPackage: 'E-commerce Basic',
                    status: 'follow_up',
                    createdAt: '2024-01-15'
                }
            ]);
        });
}

function displayProspects(prospectsData) {
    const tbody = document.getElementById('prospectsTable');
    tbody.innerHTML = '';
    
    prospectsData.forEach(prospect => {
        const row = `
            <tr>
                <td>${prospect.name || 'N/A'}</td>
                <td>${prospect.email || 'N/A'}</td>
                <td>${prospect.phone || 'N/A'}</td>
                <td>${prospect.interestedPackage || 'N/A'}</td>
                <td><span class="badge bg-warning">${prospect.status || 'Follow Up'}</span></td>
                <td>${prospect.createdAt ? new Date(prospect.createdAt).toLocaleDateString('id-ID') : 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="convertProspect(${prospect.id})">Convert</button>
                    <button class="btn btn-sm btn-primary" onclick="editProspect(${prospect.id})">Edit</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load staff
function loadStaff() {
    // Mock staff data
    const staffData = [
        {
            id: 1,
            name: 'John Developer',
            email: 'john@webmanagerpro.com',
            role: 'Developer',
            skills: 'React, Node.js',
            activeProjects: 3,
            status: 'Active'
        },
        {
            id: 2,
            name: 'Sarah Support',
            email: 'sarah@webmanagerpro.com',
            role: 'Support',
            skills: 'Customer Service',
            activeProjects: 0,
            status: 'Active'
        }
    ];
    
    displayStaff(staffData);
}

function displayStaff(staffData) {
    const tbody = document.querySelector('#staff tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    staffData.forEach(staff => {
        const row = `
            <tr>
                <td><img src="https://via.placeholder.com/40x40" class="rounded-circle" alt="Staff"></td>
                <td>${staff.name}</td>
                <td>${staff.email}</td>
                <td><span class="badge bg-${staff.role === 'Developer' ? 'success' : 'info'}">${staff.role}</span></td>
                <td>${staff.skills}</td>
                <td>${staff.activeProjects}</td>
                <td><span class="badge bg-success">${staff.status}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editStaff(${staff.id})">Edit</button>
                    <button class="btn btn-sm btn-info" onclick="assignStaff(${staff.id})">Assign</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load projects
function loadProjects() {
    // Mock projects data
    const projectsData = [
        {
            id: 1,
            projectId: '#PRJ001',
            name: 'Website Company ABC',
            client: 'PT ABC Indonesia',
            developer: 'John Developer',
            status: 'On Progress',
            progress: 75,
            deadline: '2024-02-15'
        },
        {
            id: 2,
            projectId: '#PRJ002',
            name: 'E-commerce Fashion',
            client: 'Toko Fashion Maju',
            developer: 'Maria Designer',
            status: 'Pending',
            progress: 25,
            deadline: '2024-02-28'
        }
    ];
    
    displayProjects(projectsData);
}

function displayProjects(projectsData) {
    const tbody = document.querySelector('#projects tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    projectsData.forEach(project => {
        const row = `
            <tr>
                <td>${project.projectId}</td>
                <td>${project.name}</td>
                <td>${project.client}</td>
                <td>${project.developer}</td>
                <td><span class="badge bg-${project.status === 'On Progress' ? 'primary' : 'warning'}">${project.status}</span></td>
                <td>
                    <div class="progress">
                        <div class="progress-bar ${project.status === 'On Progress' ? '' : 'bg-warning'}" style="width: ${project.progress}%">${project.progress}%</div>
                    </div>
                </td>
                <td>${project.deadline}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editProject(${project.id})">Edit</button>
                    <button class="btn btn-sm btn-info" onclick="viewProject(${project.id})">View</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load websites
function loadWebsites() {
    // Mock website data for member select
    const memberSelect = document.getElementById('memberSelect');
    if (memberSelect) {
        fetch('/api/members')
            .then(response => response.json())
            .then(data => {
                memberSelect.innerHTML = '<option>Pilih Member...</option>';
                data.forEach(member => {
                    memberSelect.innerHTML += `<option value="${member.id}">${member.name || member.email}</option>`;
                });
            });
    }
}

// Load support tickets
function loadSupportTickets() {
    fetch('/api/support-tickets')
        .then(response => response.json())
        .then(data => {
            displaySupportTickets(data);
        })
        .catch(error => {
            console.error('Error loading support tickets:', error);
            // Display mock data
            displaySupportTickets([
                {
                    id: 1,
                    ticketId: '#TIC001',
                    memberName: 'John Doe',
                    subject: 'Website Loading Issue',
                    priority: 'High',
                    status: 'Open',
                    createdAt: '2024-01-20'
                }
            ]);
        });
}

function displaySupportTickets(ticketsData) {
    const tbody = document.querySelector('#support tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    ticketsData.forEach(ticket => {
        const row = `
            <tr>
                <td>${ticket.ticketId || '#TIC' + ticket.id}</td>
                <td>${ticket.memberName || 'N/A'}</td>
                <td>${ticket.subject || 'N/A'}</td>
                <td><span class="badge bg-${ticket.priority === 'High' ? 'danger' : 'warning'}">${ticket.priority || 'Medium'}</span></td>
                <td><span class="badge bg-warning">${ticket.status || 'Open'}</span></td>
                <td>${ticket.createdAt ? new Date(ticket.createdAt).toLocaleDateString('id-ID') : 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="replyTicket(${ticket.id})">Reply</button>
                    <button class="btn btn-sm btn-success" onclick="closeTicket(${ticket.id})">Close</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Load reports
function loadReports() {
    // Initialize charts if not already done
    setTimeout(() => {
        initializeCharts();
    }, 100);
}

function initializeCharts() {
    // Sales Chart
    const salesCtx = document.getElementById('salesChart');
    if (salesCtx && !salesCtx.chartInstance) {
        salesCtx.chartInstance = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Penjualan',
                    data: [12, 19, 3, 5, 2, 3],
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            }
        });
    }
    
    // Member Chart
    const memberCtx = document.getElementById('memberChart');
    if (memberCtx && !memberCtx.chartInstance) {
        memberCtx.chartInstance = new Chart(memberCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'New Members',
                    data: [5, 8, 3, 7, 4, 6],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            }
        });
    }
}

// Add member function
function addMember() {
    const form = document.getElementById('addMemberForm');
    const formData = new FormData(form);
    const memberData = {};
    
    for (let [key, value] of formData.entries()) {
        memberData[key] = value;
    }
    
    fetch('/api/members', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(memberData)
    })
    .then(response => response.json())
    .then(data => {
        alert('Member berhasil ditambahkan!');
        loadMembers();
        document.getElementById('addMemberModal').querySelector('[data-bs-dismiss="modal"]').click();
        form.reset();
    })
    .catch(error => {
        console.error('Error adding member:', error);
        alert('Terjadi kesalahan saat menambah member');
    });
}

// Create invoice function
function createInvoice() {
    const form = document.getElementById('createInvoiceForm');
    const formData = new FormData(form);
    const invoiceData = {};
    
    for (let [key, value] of formData.entries()) {
        invoiceData[key] = value;
    }
    
    fetch('/api/invoices', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(invoiceData)
    })
    .then(response => response.json())
    .then(data => {
        alert('Invoice berhasil dibuat!');
        loadInvoices();
        document.getElementById('createInvoiceModal').querySelector('[data-bs-dismiss="modal"]').click();
        form.reset();
    })
    .catch(error => {
        console.error('Error creating invoice:', error);
        alert('Terjadi kesalahan saat membuat invoice');
    });
}

// Process auto renewal
function processAutoRenewal() {
    fetch('/api/auto-renewal/process', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        const results = data.processedRenewals;
        const successCount = results.filter(r => r.status === 'success').length;
        const failedCount = results.filter(r => r.status === 'insufficient_balance').length;
        
        alert(`Perpanjangan otomatis selesai!\nBerhasil: ${successCount}\nGagal (saldo kurang): ${failedCount}`);
        loadMembers();
    })
    .catch(error => {
        console.error('Error processing auto renewal:', error);
        alert('Terjadi kesalahan saat memproses perpanjangan otomatis');
    });
}

// Toggle auto renewal for member
function toggleAutoRenewal(memberId, enabled) {
    fetch(`/api/members/${memberId}/auto-renewal`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ enabled })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Auto renewal updated for member', memberId);
        }
    })
    .catch(error => {
        console.error('Error updating auto renewal:', error);
    });
}

// Utility functions
function editMember(id) {
    alert(`Edit member dengan ID: ${id}`);
}

function topupMember(id) {
    const amount = prompt('Masukkan jumlah top up:');
    if (amount && !isNaN(amount)) {
        fetch(`/api/members/${id}/topup`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                amount: parseInt(amount),
                method: 'admin_topup'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Top up berhasil!');
                loadMembers();
            }
        })
        .catch(error => {
            console.error('Error topping up:', error);
            alert('Terjadi kesalahan saat top up');
        });
    }
}

function editPackage(id) {
    alert(`Edit package dengan ID: ${id}`);
}

function deletePackage(id) {
    if (confirm('Yakin ingin menghapus paket ini?')) {
        alert(`Package ${id} akan dihapus`);
    }
}

function viewInvoice(id) {
    alert(`View invoice dengan ID: ${id}`);
}

function markPaid(id) {
    if (confirm('Tandai invoice sebagai terbayar?')) {
        // Update invoice status
        alert(`Invoice ${id} ditandai sebagai terbayar`);
        loadInvoices();
    }
}

function convertProspect(id) {
    if (confirm('Convert prospect menjadi member?')) {
        alert(`Prospect ${id} akan diconvert menjadi member`);
        loadProspects();
    }
}

function editProspect(id) {
    alert(`Edit prospect dengan ID: ${id}`);
}

function editStaff(id) {
    alert(`Edit staff dengan ID: ${id}`);
}

function assignStaff(id) {
    alert(`Assign tugas ke staff dengan ID: ${id}`);
}

function editProject(id) {
    alert(`Edit project dengan ID: ${id}`);
}

function viewProject(id) {
    alert(`View project dengan ID: ${id}`);
}

function replyTicket(id) {
    alert(`Reply ticket dengan ID: ${id}`);
}

function closeTicket(id) {
    if (confirm('Tutup ticket ini?')) {
        alert(`Ticket ${id} ditutup`);
        loadSupportTickets();
    }
}

// Load analytics data
function loadAnalyticsData() {
    fetch('/api/analytics/traffic')
        .then(response => response.json())
        .then(data => {
            document.getElementById('pageViews').textContent = data.pageViews.toLocaleString();
            document.getElementById('uniqueVisitors').textContent = data.uniqueVisitors.toLocaleString();
            document.getElementById('bounceRate').textContent = data.bounceRate;
            document.getElementById('avgSession').textContent = data.avgSessionDuration;
        })
        .catch(error => console.error('Error loading analytics:', error));
    
    fetch('/api/analytics/performance')
        .then(response => response.json())
        .then(data => {
            document.getElementById('uptime').textContent = data.uptime;
            document.getElementById('loadTime').textContent = data.avgLoadTime;
            document.getElementById('serverResponse').textContent = data.serverResponse;
        })
        .catch(error => console.error('Error loading performance:', error));
}

// Load payment methods
function loadPaymentMethods() {
    fetch('/api/recurring-payments')
        .then(response => response.json())
        .then(data => {
            displayRecurringPayments(data);
        })
        .catch(error => console.error('Error loading recurring payments:', error));
}

function displayRecurringPayments(data) {
    const tbody = document.getElementById('recurringPaymentsTable');
    if (tbody) {
        tbody.innerHTML = '';
        data.forEach(payment => {
            const row = `
                <tr>
                    <td>${payment.memberName || 'N/A'}</td>
                    <td>${payment.serviceName || 'N/A'}</td>
                    <td>Rp ${(payment.amount || 0).toLocaleString('id-ID')}</td>
                    <td>${payment.nextPaymentDate ? new Date(payment.nextPaymentDate).toLocaleDateString('id-ID') : 'N/A'}</td>
                </tr>
            `;
            tbody.innerHTML += row;
        });
    }
}

// Process recurring payments
function processRecurringPayments() {
    fetch('/api/recurring-payments/process', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        const successCount = data.processedPayments.filter(p => p.status === 'success').length;
        const failedCount = data.processedPayments.filter(p => p.status === 'insufficient_balance').length;
        
        alert(`Pembayaran berulang diproses!\nBerhasil: ${successCount}\nGagal: ${failedCount}`);
        loadPaymentMethods();
    })
    .catch(error => {
        console.error('Error processing recurring payments:', error);
        alert('Terjadi kesalahan saat memproses pembayaran berulang');
    });
}

// Load communications
function loadCommunications() {
    console.log('Loading communications data...');
}

// Load subscriptions
function loadSubscriptions() {
    console.log('Loading subscriptions data...');
}

// Send broadcast notification
function sendBroadcast() {
    const form = document.getElementById('broadcastForm');
    const formData = new FormData(form);
    const broadcastData = {};
    
    for (let [key, value] of formData.entries()) {
        broadcastData[key] = value;
    }
    
    fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(broadcastData)
    })
    .then(response => response.json())
    .then(data => {
        alert(`Broadcast berhasil dikirim ke ${data.sentTo} member!`);
        document.getElementById('broadcastModal').querySelector('[data-bs-dismiss="modal"]').click();
        form.reset();
    })
    .catch(error => {
        console.error('Error sending broadcast:', error);
        alert('Terjadi kesalahan saat mengirim broadcast');
    });
}

// Load performance data
function loadPerformanceData() {
    fetch('/api/analytics/performance')
        .then(response => response.json())
        .then(data => {
            document.getElementById('uptime').textContent = data.uptime;
            document.getElementById('loadTime').textContent = data.avgLoadTime;
            document.getElementById('serverResponse').textContent = data.serverResponse;
        })
        .catch(error => console.error('Error loading performance data:', error));
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadDashboardStats();
    
    // Initialize cPanel form if exists
    const cpanelForm = document.getElementById('cpanelForm');
    if (cpanelForm) {
        cpanelForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Informasi cPanel berhasil disimpan!');
        });
    }
});
