
# WebManager Pro - Sistem Manajemen Website & Klien

WebManager Pro adalah platform manajemen website dan klien yang komprehensif, dirancang untuk memudahkan pengelolaan layanan pembuatan website, hosting, dan administrasi klien.

## 🚀 Fitur Utama

### 🔐 Sistem Authentication
- **Login Admin**: Akses penuh untuk manajemen sistem
- **Login Member**: Portal khusus untuk klien/member
- Session management dengan token authentication

### 👥 Manajemen Member
- Pendaftaran dan profil member
- Dashboard member dengan overview aktivitas
- Update profil dan ganti password
- Status member dan tracking aktivitas

### 📦 Paket Layanan Website
- **30+ Paket Website** tersedia:
  - Basic Website (Rp 500.000)
  - Business Website (Rp 1.000.000)
  - E-commerce Basic/Advanced
  - Corporate Website
  - Portfolio, Blog, Restaurant Website
  - Dan banyak lagi...

### 📄 Sistem Invoice
- Generate invoice otomatis
- Tracking status pembayaran
- Export ke PDF
- Management tagihan member

### 🌐 Manajemen Website
- Informasi hosting dan domain
- Akses cPanel untuk member
- Monitoring status website
- Backup dan maintenance

### 📊 Dashboard Admin
- Overview statistik
- Manajemen member dan prospects
- Laporan keuangan
- Support ticket system

## 🛠️ Teknologi yang Digunakan

- **Backend**: Node.js + Express.js
- **Frontend**: HTML5, CSS3, JavaScript ES6+
- **UI Framework**: Bootstrap 5
- **Icons**: Font Awesome 6
- **Authentication**: JSON Web Token (JWT)
- **Password Hashing**: bcryptjs
- **File Upload**: Multer

## 📋 Prerequisites

- Node.js (versi 18+ recommended)
- NPM atau Yarn package manager

## 🚀 Instalasi & Setup

### 1. Clone Repository
```bash
git clone <repository-url>
cd webmanager-pro
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Jalankan Aplikasi
```bash
npm start
# atau
node index.js
```

### 4. Akses Aplikasi
- **Website Utama**: http://localhost:5000
- **Login Page**: http://localhost:5000/login.html
- **Admin Dashboard**: http://localhost:5000/dashboard
- **Member Dashboard**: http://localhost:5000/member-dashboard

## 🔑 Default Login Credentials

### Admin Login
- **Username**: admin
- **Password**: admin123

### Member Login
*Note: Member harus didaftarkan terlebih dahulu melalui admin dashboard*

## 📁 Struktur Proyek

```
webmanager-pro/
├── public/                 # Frontend files
│   ├── index.html         # Landing page
│   ├── login.html         # Login page
│   ├── dashboard.html     # Admin dashboard
│   ├── member-dashboard.html # Member dashboard
│   └── dashboard.js       # Dashboard functionality
├── index.js              # Main server file
├── package.json          # Dependencies
└── README.md             # Documentation
```

## 🎯 Fitur Dashboard Admin

### 📊 Overview
- Total member aktif
- Invoice pending/lunas
- Website aktif
- Support tickets

### 👥 Manajemen Member
- Tambah/edit/hapus member
- View profil lengkap member
- Export data member

### 📦 Manajemen Paket
- 30+ paket website siap pakai
- Customizable pricing
- Feature management

### 📄 Invoice Management
- Auto-generate invoice
- PDF export
- Payment tracking
- Email notifications

### 🎫 Support System
- Ticket management
- Response tracking
- Priority levels

## 🎯 Fitur Member Dashboard

### 📊 Overview Member
- Website aktif
- Invoice status
- Support tickets
- Aktivitas terbaru

### 👤 Profil Management
- Update informasi personal
- Ganti password
- Company details

### 🌐 Website Management
- List website aktif
- cPanel access links
- Domain information
- SSL status

### 📄 Invoice & Billing
- Riwayat pembayaran
- Download invoice PDF
- Upcoming payments

## 🚀 Deployment

### Deploy di Replit
1. Fork/import project ke Replit
2. Install dependencies otomatis
3. Klik tombol "Run"
4. Aplikasi siap digunakan

### Environment Variables
```
PORT=5000
NODE_ENV=production
```

## 🔧 Konfigurasi

### Port Configuration
- Default port: 5000
- Dapat diubah melalui environment variable PORT

### Database
- Saat ini menggunakan in-memory storage
- Untuk production, integrasikan dengan database (MongoDB/PostgreSQL)

## 📝 API Endpoints

### Authentication
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/member/login` - Member login

### Members
- `GET /api/members` - Get all members
- `POST /api/members` - Create new member

### Packages
- `GET /api/packages` - Get all packages

### Invoices
- `GET /api/invoices` - Get all invoices
- `POST /api/invoices` - Create new invoice
- `GET /api/invoices/:id/pdf` - Download invoice PDF

### Prospects
- `GET /api/prospects` - Get prospects
- `POST /api/prospects` - Create prospect

## 🛡️ Security Features

- Password hashing dengan bcryptjs
- JWT token authentication
- Session management
- Input validation
- CORS protection

## 🚧 Roadmap & Future Features

- [ ] Database integration (MongoDB/PostgreSQL)
- [ ] Email notifications
- [ ] Payment gateway integration
- [ ] Real-time chat support
- [ ] Mobile responsive improvements
- [ ] Advanced reporting
- [ ] Backup automation
- [ ] Multi-language support

## 🤝 Contributing

1. Fork the project
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**WebManager Pro Team**
- Website: [Your Website]
- Email: admin@webmanagerpro.com

## 🆘 Support

Jika mengalami masalah atau membutuhkan bantuan:
1. Buka issue di GitHub repository
2. Email ke: support@webmanagerpro.com
3. Dokumentasi lengkap tersedia di wiki

---

**WebManager Pro** - Solusi Lengkap Manajemen Website & Klien 🚀
